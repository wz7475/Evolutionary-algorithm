# dimension of this problem - len of resources
POPULATION_SIZE = 100  # significantly bigger than dimension
CROSS_PROBABILITY = 0.8  # close to 1
MUTATION_STRENGTH = 0.01
ITERATIONS = 100
